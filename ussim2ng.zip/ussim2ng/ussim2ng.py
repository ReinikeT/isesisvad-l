import sys, time, random
import pygame


pygame.init()
event = pygame.event.wait()

# Difficulty settings
# Easy      ->  10
# Medium    ->  25
# Hard      ->  40
# Harder    ->  60
# Impossible->  120
difficulty = 120

# Window size
frame_size_x = 720
frame_size_y = 480

#Font
small_font=pygame.font.SysFont("comic sans ms",25)
medium_font = pygame.font.SysFont('comic sans ms', 30, True)
large_font = pygame.font.SysFont('comic sans ms', 60, True, True)
clock = pygame.time.Clock() #kell
#Pildid
snake_img=pygame.image.load("img/snake2.png")
tail_img=pygame.image.load("img/tail1.png")
apple_img=pygame.image.load("img/apple2.png")

# Colors (R, G, B) ja suurused
black=(0,0,0)
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)
blue = (0, 0, 255)
yellow=(250,253,15)
lyellow=(173,255,47)
fgreen=(34,139,34)

VELOCITY = 10
SNAKE_WIDTH = 15
APPLE_SIZE = 20
TOP_WIDTH = 40

# FPS (frames per second) controller
fps_controller = pygame.time.Clock()
FPS = pygame.time.Clock()


# Checks for errors encountered
check_errors = pygame.init()
# pygame.init() example output -> (6, 0)
# second number in tuple gives number of errors
if check_errors[1] > 0:
    print(f'[!] Had {check_errors[1]} errors when initialising game, exiting...')
    sys.exit(-1)
else:
    print('[+] Game successfully initialised')

# Initialise game window
pygame.display.set_caption('Snake Eater')
game_window = pygame.display.set_mode((frame_size_x, frame_size_y))
canvas = pygame.display.set_mode(((frame_size_x, frame_size_y)))

# Game Over
def gameover():
    my_font = pygame.font.SysFont('times new roman', 90)
    game_over_surface = my_font.render('YOU DIED', True, red)
    game_over_rect = game_over_surface.get_rect()
    game_over_rect.midtop = (frame_size_x / 2, frame_size_y / 4)
    game_window.fill(black)
    game_window.blit(game_over_surface, game_over_rect)
    show_score(0, red, 'times', 20)
    pygame.display.flip()
    pygame.mixer.quit()
    mp3_path = 'sound/death.wav'
    pygame.init()
    pygame.mixer.init()
    pygame.mixer.music.load(mp3_path)
    pygame.mixer.music.play(-1)
    time.sleep(4)

    pygame.quit()
    sys.exit()
def pause():
    paused=True
    while paused:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key==pygame.K_ESCAPE:
                    paused = False

                elif event.key == pygame.K_q:
                    pygame.quit()
                    quit()
        paused_font1 = large_font.render("Game Paused", True, red)
        paused_font_rect1 = paused_font1.get_rect()
        paused_font_rect1.center = (frame_size_x / 2, frame_size_y / 2)
        canvas.blit(paused_font1, paused_font_rect1)
        pygame.display.update()
        clock.tick(5)



def game_paused():
    # canvas.fill(BLACK)
    paused_font1 = large_font.render("Game Paused", True, red)
    paused_font_rect1 = paused_font1.get_rect()
    paused_font_rect1.center = (frame_size_x/2, frame_size_y/2)
    canvas.blit(paused_font1, paused_font_rect1)

    paused=True
    while paused:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    game_paused=False

                elif event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                pause_xy = event.pos
                if pause_xy[0] > (frame_size_x - 50) and pause_xy[0] < frame_size_x:
                    if pause_xy[1] > 0 and pause_xy[1] < 50:
                        return
        pygame.display.update()
        clock.tick(4)

def gameloop():

    while True:

        LEAD_X = 0
        LEAD_Y = 100
        direction = 'right'
        score = small_font.render("Score:0", True, yellow)
        APPLE_X = random.randrange(0, frame_size_x - 10, 10)
        APPLE_Y = random.randrange(TOP_WIDTH, frame_size_y - 10, 10)
        snakelist = []
        snakelength = 3
        pause_font = medium_font.render('II', True, red)


        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:

                    if event.key == pygame.K_LEFT:
                        if direction == 'right':
                            pass
                        else:
                            direction = 'left'
                    if event.key == pygame.K_RIGHT:
                        if direction == 'left':
                            pass
                        else:
                            direction = 'right'
                    if event.key == pygame.K_UP:
                        if direction == 'down':
                            pass
                        else:
                            direction = 'up'
                    if event.key == pygame.K_DOWN:
                        if direction == 'up':
                            pass
                        else:
                            direction = 'down'
                    if event.key == pygame.K_ESCAPE:
                        pause()

                #if event.key == pygame.K_ESCAPE:
                 #   game_paused()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pause_xy = event.pos
                    if pause_xy[0] > (frame_size_x - 50) and pause_xy[0] < frame_size_x:
                        if pause_xy[1] > 0 and pause_xy[1] < 50:
                            game_paused()
            if direction == 'up':
                LEAD_Y -= VELOCITY
                if LEAD_Y < TOP_WIDTH:
                    gameover()
            if direction == 'down':
                LEAD_Y += VELOCITY
                if LEAD_Y > frame_size_y - SNAKE_WIDTH:
                    gameover()
            if direction == 'right':
                LEAD_X += VELOCITY
                if LEAD_X > frame_size_x - SNAKE_WIDTH:
                    gameover()
            if direction == 'left':
                LEAD_X -= VELOCITY
                if LEAD_X < 0:
                    gameover()

            snakehead = []
            snakehead.append(LEAD_X)
            snakehead.append(LEAD_Y)
            snakelist.append(snakehead)

            snake_head_rect = pygame.Rect(LEAD_X, LEAD_Y, SNAKE_WIDTH, SNAKE_WIDTH)
            apple_rect = pygame.Rect(APPLE_X, APPLE_Y, APPLE_SIZE, APPLE_SIZE)


            if len(snakelist) > snakelength:
                del snakelist[0]
            for point in snakelist[:-1]:
                if point == snakehead:
                    gameover()

            canvas.fill(black)

            snake(snakelist, direction)
            if snake_head_rect.colliderect(apple_rect):
                APPLE_X = random.randrange(0, frame_size_x - 10, 10)
                APPLE_Y = random.randrange(TOP_WIDTH, frame_size_y - 10, 10)
                snakelength += 1
                score = small_font.render("Score:" + str(snakelength - 3), True, yellow)
                pygame.mixer.find_channel().play(pygame.mixer.Sound("sound/collect.wav"))
            canvas.blit(score, (20, 10))
            pygame.draw.line(canvas, green, (0, TOP_WIDTH), (frame_size_x, TOP_WIDTH))
            pygame.draw.line(canvas, yellow, (frame_size_x - 60, 0), (frame_size_x - 60, TOP_WIDTH))
            pygame.draw.rect(canvas, yellow, (frame_size_x - 60, 0, 60, TOP_WIDTH))
            canvas.blit(pause_font, (frame_size_x - 45, 1))
            canvas.blit(apple_img, (APPLE_X, APPLE_Y))
            pygame.display.update()

            clock.tick(60)

def snake(snakelist, direction):

    if direction == 'right':
        head = pygame.transform.rotate(snake_img, 270)
        tail = pygame.transform.rotate(tail_img, 270)
    if direction == 'left':
        head = pygame.transform.rotate(snake_img, 90)
        tail = pygame.transform.rotate(tail_img, 90)
    if direction == 'up':
        head = pygame.transform.rotate(snake_img, 0)
        tail = pygame.transform.rotate(tail_img, 0)
    if direction == 'down':
        head = pygame.transform.rotate(snake_img, 180)
        tail = pygame.transform.rotate(tail_img, 180)

    canvas.blit(head, snakelist[-1])
    canvas.blit(tail, snakelist[0])

    for XnY in snakelist[1:-1]:
        pygame.draw.rect(canvas, blue, (XnY[0], XnY[1], SNAKE_WIDTH, SNAKE_WIDTH))

# Game variables
snake_pos = [100, 50]
snake_body = [[100, 50], [100 - 10, 50], [100 - (2 * 10), 50]]

food_pos = [random.randrange(1, (frame_size_x // 10)) * 10, random.randrange(1, (frame_size_y // 10)) * 10]
food_spawn = True

direction = 'RIGHT'
change_to = direction

score = 0
RUNNING,PAUSE=0,1





# Score
def show_score(choice, color, font, size):
    score_font = pygame.font.SysFont(font, size)
    score_surface = score_font.render('Score : ' + str(score), True, color)
    score_rect = score_surface.get_rect()
    if choice == 1:
        score_rect.midtop = (frame_size_x / 10, 15)
    else:
        score_rect.midtop = (frame_size_x / 2, frame_size_y / 1.25)
    game_window.blit(score_surface, score_rect)
    # pygame.display.flip()




# Main THEMES
pygame.mixer.music.load("sound/music.mp3")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(loops=-1)

pygame.mixer.Channel(1).play(pygame.mixer.Sound('sound/music.mp3'), maxtime=600)

def creator():
    canvas.fill(black)
    my_img = pygame.image.load('image1.jpg')
    my_img_rect = my_img.get_rect()
    my_img_rect.center = (frame_size_x/2, my_img_rect.height/2 + 20)
    canvas.blit(my_img, my_img_rect)

    start_inst1 = large_font.render("Surya Prakash Reddy", False, green)
    start_inst1_rect = start_inst1.get_rect()
    start_inst1_rect.center = (frame_size_x/2, 420)
    canvas.blit(start_inst1, start_inst1_rect)

    start_inst2 = small_font.render("Hello guys, This is Surya. Thanks for playing my game.", True, blue)
    start_inst3 = small_font.render("This is a very simple game, developed using python", True, blue)
    start_inst4 = small_font.render("In case of queries, write to surajchinna1@gmail.com", True, blue)
    canvas.blit(start_inst2, (10, 470))
    canvas.blit(start_inst3, (10, 500))
    canvas.blit(start_inst4, (10, 530))



    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                if x > start_inst5_rect.left and x < start_inst5_rect.right:
                    if y > start_inst5_rect.top and y < start_inst5_rect.bottom:
                        start_game()
        pygame.display.update()

def start_inst(start_font1, start_font1_rect):
    canvas.fill(lyellow)
    canvas.blit(start_font1, start_font1_rect)
    start_inst1 = small_font.render("--> Ära puuduta ääri, muidu sa sured", True, fgreen)
    start_inst2 = small_font.render("--> Söö punaseid õunu, et suuremaks saada", True, fgreen)
    start_inst3 = small_font.render("--> Ära mine enda pihta", True, fgreen)


    start_inst5_rect = start_inst5.get_rect()
    start_inst5_rect.center = (frame_size_x-100, frame_size_y - 100)

    canvas.blit(start_inst1, (frame_size_x/8, frame_size_y/2))
    canvas.blit(start_inst2, (frame_size_x/8, frame_size_y/2 + 30))
    canvas.blit(start_inst3, (frame_size_x/8, frame_size_y/2 + 60))

    canvas.blit(start_inst5, start_inst5_rect)
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                if x > start_inst5_rect.left and x < start_inst5_rect.right:
                    if y > start_inst5_rect.top and y < start_inst5_rect.bottom:
                        start_game()
        pygame.display.update()

start_bg=pygame.image.load("img/snake_game_background.jpg")
def start_game():
    canvas.fill(lyellow)
    start_font1 = large_font.render("Ussikas", True, fgreen)
    start_font2 = medium_font.render("Start", True, fgreen, lyellow)
    start_font3 = medium_font.render("juhend", True, fgreen, lyellow)
    start_font4 = medium_font.render("Lahku", True, fgreen, lyellow)


    start_font1_rect = start_font1.get_rect()
    start_font2_rect = start_font2.get_rect()
    start_font3_rect = start_font3.get_rect()
    start_font4_rect = start_font4.get_rect()


    start_font1_rect.center = (frame_size_x/2, frame_size_y/2 - 100)
    start_font2_rect.center = (frame_size_x/2 + 100, frame_size_y/2 + 50)
    start_font3_rect.center = (frame_size_x/2 + 100, frame_size_y / 2 + 100)

    start_font4_rect.center = (frame_size_x/2 + 100, frame_size_y/2 + 200)

    canvas.blit(start_font1, start_font1_rect)
    canvas.blit(start_font2, start_font2_rect)
    canvas.blit(start_font3, start_font3_rect)
    canvas.blit(start_font4, start_font4_rect)

    pygame.display.update()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    game_paused()
                if event.key == pygame.K_s:
                    gameloop()
                if event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                if x > start_font3_rect.left and x < start_font3_rect.right:
                    if y > start_font3_rect.top and y < start_font3_rect.bottom:
                        start_inst(start_font1, start_font1_rect)
                if x > start_font2_rect.left and x < start_font2_rect.right:
                    if y > start_font2_rect.top and y < start_font2_rect.bottom:
                        gameloop()

                if x > start_font4_rect.left and x < start_font4_rect.right:
                    if y > start_font4_rect.top and y < start_font4_rect.bottom:
                        pygame.quit()
                        sys.exit()



        pygame.display.update()




start_inst5 = medium_font.render("<<Tagasi", True, red, fgreen)
start_inst5_rect = start_inst5.get_rect()
start_inst5_rect.center = (frame_size_x - start_inst5_rect.width / 2, frame_size_y - start_inst5_rect.height / 2)
canvas.blit(start_inst5, start_inst5_rect)
pygame.display.update()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if x > start_inst5_rect.left and x < start_inst5_rect.right:
                if y > start_inst5_rect.top and y < start_inst5_rect.bottom:
                    start_game()
    pygame.display.flip()
