from tkinter import * #impordib tkinteri
import os #impordib os

#ekraani 2 sulgemine
def delete2():
    screen3.destroy()

#ekraani 3 sulgemine
def delete3():
    screen3.destroy()

#ekraani 4 sulgemine
def delete4():
    screen5.destroy()

#sisse logimine õnnestus
def login_success():
    global screen3 #globaliseerib screen3
    screen3 = Toplevel(screen) #ekraan
    screen3.title("Õnnestus") #ekraani pealkiri
    screen3.geometry("150x100") #ekraani suurus
    Label(screen3, text="Sisselogimine õnnestus").pack() #tekst "Sisselogimine õnnestus"
    Button(screen3, text="OK", command=delete2).pack() #nupp nimega ok. see sulgeb ekraani

def password_not_recognised(): #defineerib parooli ei tuvastatud
    global screen4 #globaliseerib screen4
    screen4 = Toplevel(screen) #kuvab ekraani
    screen4.title("vale parool") #ekraani pealkiri
    screen4.geometry("150x100")#ekraani suurus
    Label(screen4, text="Vale parool").pack() #Kuvatakse tekst, vale parool
    Button(screen4, text="OK", command=delete3).pack() #Nupp kus on kirjas OK. See sulgeb ekraani

def user_not_found(): #Defineerib kasutajat ei leitud
    global screen5 #globaliseerib screen5
    screen5 = Toplevel(screen) #Kuvab ekraani
    screen5.title("user error") #ekraani pealkiri
    screen5.geometry("150x100") #ekraani suurus
    Label(screen5, text="kasutajat ei leitud").pack() #ekraanil kuvatakse tekst "Kasutajat ei leitud"
    Button(screen5, text="OK", command=delete4).pack() #nupp kus peal on kirjas OK. See sulgeb ka ekraani

def register_user(): #defineerib kasutaja registreerimise
    print("Working") #prindib working
    #Poroolide ja nime saamine
    username_info = username.get()
    password_info = password.get()

    #Kasutajainfo faili panemine (for safe keeping)
    file = open(username_info, "w") #loob faili username_info kirjutamise õigustega
    file.write(username_info+"\n") #kirjutab username_info
    file.write(password_info) #kirjutatakse parooli info
    file.close() #suleb faili

    #Kustutab kirjutatu.
    username_entry.delete(0, END)
    password_entry.delete(0, END)

    #Kui registeerimine õnnestus, antakse see kasutajale teada.
    Label(screen1, text = "Registratsioon õnnestus! ", fg = "green", font = ("calibri", 11)).pack()

def register(): #defineerib registreerimise
    global screen1 #globaliseerib screen1
    screen1 = Toplevel(screen) #loob ekraani
    screen1.title("Registeerimine") #ekraanipealkiri
    screen1.geometry("300x250") #ekraani suurus

    global username #globaliseerib kasutajanime
    global password #globaliseerib parooli
    global username_entry #globaliseerib sisetatud kasutajanime
    global password_entry #globaliseerib parooli  sisestamise
    username = StringVar() #kasutaja nime on sõne
    password = StringVar() #parool on sõme

    Label(screen1, text = "Palun sisestage kasutajadetailid siia: ").pack() #ekraanil kuvatakse tekst "Palun sisestae kasutajadetailid siia"
    Label(screen1, text = "").pack() #Tühi rida
    Label(screen1, text = "Kasutajanimi : ").pack() #ekraanil kuvatakse tekst kasutajanimi

    global username_entry1 #globaliseerib kasutajanime sisestamise
    global password_entry1 #globaliseerib parooli sisestamise

    username_entry = Entry(screen1, textvariable = username) #kasutajanime sisestamise
    username_entry.pack()
    Label(screen1, text = "Parool : ").pack() #tekst ekraanil "parool"
    password_entry = Entry(screen1, textvariable = password) #parooli sisestamine
    password_entry.pack()

    Button(screen1, text = "Registeerimine", width = 10, height = 1, command = register_user).pack() #registreerimise nupp

#defineerib sisselogimise tuvastamise
def login_verify():
    username1 = username_verify.get() #kasutajanime saamine
    password1 = password_verify.get() #parooli saamine
    username_entry1.delete(0, END) #kustutab kasutajanime sisestuse
    password_entry1.delete(0, END) #kustutab parooli sisestamise


    list_of_files = os.listdir() #failide kasutamine
    if username1 in list_of_files: #kui kasutajanimi on sama mis on failis
        file1 = open(username1, "r") #avatakse fail lugemis õigusega
        verify = file1.read().splitlines() #kontrollitakse kas kasutajanimi on sama
        if password1 in verify: #kui parool on sama
            login_success() #sisselogimine õnnestus ekraani kuvamine
        else: #muu
            password_not_recognised() #parooli ei tuvastatud

    else: #muu
        user_not_found() #kasutajat ei leitud




def login(): #defineerib sisselogimise
    global screen2 #globaliseerib ekraan2
    screen2 = Toplevel(screen) #kuvatakse ekraan2
    screen2.title("Sisselogimine") #ekraani pealkiri on sisselogimine
    screen2.geometry("300x250") #ekraani suurus

    Label(screen2, text = "Palun sisestage kasutajadetailid siia logimiseks: ").pack() #ekraanil kuvatakse tekst "Palun sisestage kasutajadetailid siia sisselogimiseks.
    Label(screen2, text = "").pack() #Tühi rida

    global username_verify #globaliseerib username_verify
    global password_verify #globaliseerib password_verify

    username_verify = StringVar() #kasutajanimi on sõne
    password_verify = StringVar() #parool on sõne

    global username_entry1 #globaliseerib kasutajanime sisestuse
    global password_entry1 #globaliseerib parooli sisestuse

    Label(screen2, text = "Kasutajanimi : ").pack() #teksts "Kasutajanimi
    username_entry1 = Entry(screen2, textvariable = username_verify) #kasutajanime sisestamine
    username_entry1.pack()
    Label(screen2, text = "").pack() #Tühi rida

    Label(screen2, text = "Parool : ").pack() # Tekst "Parool"
    password_entry1 = Entry(screen2, textvariable=password_verify) #Parooli sisestamine
    password_entry1.pack()

    Label(screen2, text = "").pack()#Tühi rida

    Label(screen2, text = "").pack()#Tühi rida
    Button(screen2, text = "Login", width = 10, height = 1, command = login_verify).pack() #Nupp, Kus peal on kirjas Login. Pärast seda kood kontrollib kas parool ja kasutajanimi klapivad

def main_screen(): #defineerib põhiekraani
    global screen #globaliseerib ekraani
    screen = Tk() #kuvab ekraani
    screen.geometry("300x250") #ekraani suurus
    screen.title("Notes 0.1") #ekraani pealkiri
    Label(text = "Notes 0.1)", bg = "grey", width = "300", height = "2", font = ("Calibri", 13)).pack() #ekraanil kuvatakse tekst "Notes 0.1"

    Label(text = "").pack() #Tühi rida
    Button(text = "Login", height = "2", width = "30", command = login).pack() #sisselogimis nupp
    Label(text = "").pack() #Tühi rida
    Button(text = "Registeerimine", height = "2", width = "30", command = register).pack() #registreerimise nupp

    #Ekraan pantakse loopi (et kasutada saaks ilusti)
    screen.mainloop() #ekraani luup

#Käivitatakse programm. ;p
main_screen() #käivitatakse põhiekraan