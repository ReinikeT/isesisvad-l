from tkinter import* #import tkinter

def register_user(): #defineerib kasutaja registreerimise
    username_info=username.get() #võtab kasutaja sisestatud kasutajanime
    password_info=password.get() #võtab kasutaja sisestatud passwordi

    file=open(username_info+".txt", "w") #avab faili username_info.txt
    file.write(username_info+"\n") #kirjutab kasutaja kasutajanime
    file.write(password_info+"\n") #kirjutab kasutaja parooli
    file.close() #sulgeb faili

    username_entry.delete(0, END) #kustutab kasutaja sisestatud kasutajanime
    password_entry.delete(0, END) #kustutab kasutaja sisestatud parooli

    Label(screen1, text="Registration success", fg="green", font=("calibri", 11)).pack() #kuvatakse tekst. Registratsioon õnnestus

def register(): #defineerib registreerimise
    screen1 = Toplevel(screen) #teeb uue ekraani
    screen1.title("Register") #uue ekraani pealkiri on register
    screen1.geometry("300x250") #ekraani suurus on 300x250
    global screen1 #globaliseerib ekraani1
    global username #globaliseerib kasutajanime
    global password #globalirseerib parooli
    global username_entry #globaliseerib kasutajanime sisestuse
    global password_entry #globaliseerib parooli sisestuse

    username = StringVar #kasutajanimi on sõnes
    passowrd = StringVar #parool on sõne

    Label(text="Please enter details below").pack() #tekst Palun sisestage detailid all pool
    Label(text="").pack() #tühi rida
    Label(screen1, text="Username *").pack() #Kasutajanimi
    username_entry = Entry(screen1, textvariable=username) #kasutajanime sisestamine
    username_entry.pack()
    Label(screen1, text="Password *").pack() #parool
    password_entry = Entry(screen1, textvariable=passowrd) #parooli sisestamine
    password_entry.pack()
    Label(text="").pack()  #tühi rida
    Button(screen1, text= "Register", width=10, height=1).pack() #registreerimise nupp

def Login(): #defineerib sisselogimise
    print("Login session start") #prindib login session started


def main_screen(): #defineerib põhiekraani
    global screen #globaliseerib ekraani
    screen=Tk()  #loob ekraani
    screen.geometry("300x250") #ekraani suurus
    screen.title("Notes 1.0") #ekraani pealkiri
    Label(text="Notes 1.0", bg="grey", width="300", height="2", font=("Calibri", 13)).pack() #ekraani pealkiri
    Label(text="").pack()  #tühi rida
    Button(text="Login", height="2", width="30").pack() #Sisselogimis nupp
    Label(text="").pack()  #tühi rida
    Button(text="Register", height="2", width="30", command=register).pack() #registreerimise nupp

    screen.mainloop() #paneb ekraani luupi

main_screen() #käivitab põhiekraani






