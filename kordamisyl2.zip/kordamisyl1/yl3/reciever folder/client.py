import socket #impordib socketi
s=socket.socket() #teeb socket.socket() muutujaks, et seda oleks lihtsam kasutada
host=input(str("Please enter the host address of sender: ")) #Klient sisestab serveri nime
port=8080 #serveri port
s.connect((host,port)) #ühendab serveriga
print("Connected ...") #Kui hosti nimi oli õige, siis prindib "connected.

#Recive fail
filename=input(str("Please ener a file name for the incoming file: ")) #kasutaja sisestab faili nime sellele mis talle saadetakse
file = open(filename, "wb") #Avab faili
file_data = s.recv(1024) #loeb faili sisu
file.write(file_data) #kirjutab faili
file.close() #sulgeb faili
print("File has been received succesfully") #prindib, et fail on edukalt kättesaadud