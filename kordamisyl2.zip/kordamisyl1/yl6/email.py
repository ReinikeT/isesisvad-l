import smtplib #impordib smtplib


sender_email = "vikk.opilane@outlook.com" #saatja email
rec_email = "tauri.reinike@vikk.ee" #saaja email
password  =input(str("Please etner your password: ")) #saatja parool
message = "Hey, this was sent using python" #kiri

server = smtplib.SMTP('smtp-mail.outlook.com', 587) #serveri email
server.starttls()
server.login(sender_email,password) #kontosse sisselogimine
print("Login success") #prindib "Login success
server.sendmail(sender_email,rec_email,message) #saadab emaili
print("Email has been sent to ", rec_email) #prindib "email has been sent to "







