from tkinter import * #impordib tkinteri

def save_info(): # defineerib info salvestamise
    firstname_info = firstname.get() #võtab kasutaja sisestatud eeznime
    lastname_info = lastname.get() #võtab kasutaja sisestadus perenime
    age_info = age.get() #võtab kasutaja sisestatud vanuse
    age_info =str(age_info) #teeb vanuse numbri tekstiks
    print(firstname_info, lastname_info, age_info) #prindib eesnime, perenime ja vanuse

    file = open("user.txt", "w") #avab faili. Kui see puudub tehakse uus fail
    file.write("Firstname: " + firstname_info) #Faili kirjutatakse eesnimi
    file.write("Lastname: " + lastname_info) #Faili kirjutatakse perenimi
    file.write("Age: " + age_info) #Faili kirjutatakse vanus
    file.close() #Fail suletakse
    print("User ", firstname_info, "has been registered succesfully") #prinditakse, User "eesnimi" has been registered succesfully

    firstname_entry.delete(0, END) #kustutab eesnime
    lastname_entry(0, END) #kustutab perenime
    age_entry(0, END) #kustutab vanuse
screen = Tk() #tkinteri ekraani kuvamine
screen.geometry("500x500") #ekraani suurus
screen.title("Python Form") #ekraani pealkiri
heading = Label(text="Python Form", bg="grey", fg="black", height="2", width="500") #pealkiri mis kuvatakse ekraanis
heading.pack()

firstname_text = Label(text="Firstname *")#eesnimi sisestamise koht
lastname_text = Label(text="Lastname *") #perenime sisestamise koht
age_text = Label(text="Age *") #vanuse sisestamise koht
firstname_text.place(x=15, y=70) #eesnime teksti asukoht ekraanil
lastname_text.place(x=15, y=100) #Perenime teksti asukoht ekraanil
age_text.place(x=15, y=210) #Vanuse teksti asukoht ekraanil

firstname = StringVar() #eesnimi on sõne
lastname = StringVar() #perenimi on sõne
age = IntVar() #vanus on number

firstname_entry = Entry(textvariable=firstname, width=30) #Eesnime sisestamise väli
lastname_entry = Entry(textvariable=lastname, width=30) #Perenime sisestamise väli
age_entry = Entry(textvariable=age, width=30) #vanuse sisestamise väli

firstname_entry.place(x=15, y=100) #eesnime sisestamise välia asukoht
lastname_entry.place(x=15, y=180) #perenime sisestamise välja asukoht
age_entry.place(x=15, y=240) #vanuse sisestamise välja asukoht

register = Button(text="Register", width="30", height="2", command=save_info, bg = "grey") #register nupp
register.place(x=15, y=290) #register nupu asukoht






