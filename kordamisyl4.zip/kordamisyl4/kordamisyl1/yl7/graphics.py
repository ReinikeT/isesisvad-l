#impordid
from tkinter import * #impordib tkinteri

#defineerib run
def run():
    name1 = name_storage.get() #võtab sisestatud nime
    print(name1) #prindib name1
    name.delete(0, END) #kustutab nime

#ekraan
screen = Tk() #loob ekraani
screen.title("Graafika") #ekraani pealkiri
screen.geometry("500x500")#ekraani suurus

welcome_text = Label(text="Tere tulemast siia programmi ", fg="red", bg="yellow") #teretulemast tekst.
welcome_text.pack()

click_me = Button(text="Vajuta siia", fg="red", bg="yellow", command=run) #nupp
click_me.place(x=10, y=20) #määrab nuppu asukoha

name_storage = StringVar()
name = Entry(textvariable=name_storage) #kasutaja sisestab nime
name.pack()
screen.mainloop() #loop