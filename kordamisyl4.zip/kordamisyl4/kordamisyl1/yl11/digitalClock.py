#impordib vajalikud asjad
from tkinter import Tk
from tkinter import Label
import time

master = Tk() #ekraan
master.title("Digital Clock") #ekraani pealkiri

def get_time(): #defineerib get_time
    timeVar = time.strftime("%I:%M:%S %p") #võtab süsteemist kella aja
    clock.config(text=timeVar) #configureerib kella
    clock.after(200, get_time) #kella tiksumine

Label(master, font=("Arial", 30), text="Digial Clock", fg="White", bg="black").pack() #kella pealkiri
clock = Label(master, font=("Arial", 100), bg="black", fg="white") #kuvab kella
clock.pack()

get_time() #käivitab get_time() funktsiooni

master.mainloop() #loop
