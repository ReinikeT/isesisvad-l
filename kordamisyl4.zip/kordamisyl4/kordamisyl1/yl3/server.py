import socket #impordib socket

s=socket.socket() #teeb s muutuja, et oleks lihtsam kasutada socekt.socket() koodi rida
host=socket.gethostname() #kuvab hosti nime
port=8080 #port
s.bind((host,port)) #kontrollib porti ja arvuti nime
s.listen(1) #ootab, et keegi ühendaks end serveriga
print(host) #prindib hosti
print("Waiting for any incoming connections ...") # prindib, "Waitig for any incoming connections ..."
conn, addr = s.accept() #Võtab vastu kliendi arvuti, kui hosti nimi vastab tõele
print(addr,"has connected to the server") #prindib kliendi IP aadressi ja ütleb, et see seade on edukalt ühendatud serveriga

filename=input(str("Please enter the filename of the file: ")) #serveri kasutaja sisestab failinime, mida ta soovib saata
file = open(filename, "rb") #fail avatakse
file_data = file.read(1024) #faili sisu loetakse
conn.send(file_data) #saadab faili
print("Data has veen transmitted succesfully") #prinditakse,et fail on edukalt edastatud
