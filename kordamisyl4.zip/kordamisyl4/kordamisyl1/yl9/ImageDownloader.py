import requests # Impordib requesti

def download_files(url): # Defineerib downlad_files
    local_filename = url.split('/')[-1] # local_filename
    with requests.get(url, stream=True) as r: # võtab url
        print("Laeb alla...") # Prindib "Downloading..."
        with open("C:/Users/tauri.reinike/Desktop/"+local_filename, 'wb') as f: # Defineerib  local_filename
            print("Kirjutab andmed faili") # Printib "Writing data to file"
            for chunk in r.iter_content(chunk_size=8192): # Defineerib chunk
                f.write(chunk) # Kirjutab faili chunki
    f.close() # Sulgeb faili
    print("installeerimine õnnestus") # Prindib "Download complete"
    print("File saved as "+ local_filename) # Prindib "File saved as "+ local_filename

while 1: # loop
    print("Tere tulemast pildi allalaadimis haldurisse") # Prindib "Welcome to the image downloader"
    image_url = input(str("Pildi URL: ")) # küsib linki, mille peab kasutaja sisestama
    download_files(image_url) # laeb faili alla
    print("") # prindib tühjarea