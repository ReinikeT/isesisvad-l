#impordib asjad
import random
#parooli jaoks mõeldud tähed, sümbolid ja numbrid
chars = "abcdefghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456!£$%&*(')"

#loop
while 1:
    password_len = int(input("Kui pikka parooli Te soovite: ")) #kasutaja sisestab parooli pikkuse.
    password_count = int(input("Mitu parooli Te soovite: ")) #kasutaja sisestab mitu parooli ta tahab
    for x in range(0,password_count): #prindib, mitmes parool see on
        print(x) #prindib need
        password = ""
        for x in range(0,password_len): #prindib  parooli pikkuse
            password_char = random.choice(chars) #võtab suvalised tähed
            password = password + password_char
        print("Siin on Teie parool: ", password) #prindib parooli