#Tauri Reinike


import pygame,time #impordib pygame ja aja
pygame.init() #käivitab pygame

#Kell
clock = pygame.time.Clock()
startTime=time.time()



#Värvid
lblue=(34,167,225) #helesinine

#Ekraani seaded
screenX=640 #Ekraani laius
screenY=480 #Ekraani kõrgus
screen=pygame.display.set_mode([screenX,screenY]) #loob ekraani
pygame.display.set_caption("Ping-pong") #Paneb ekraanile pealkirja
screen.fill(lblue) #Täidab ekraani helesinise värviga


myfont = pygame.font.SysFont("monospace", 25) #monospace font kuvatavate tekstide jaoks



label = myfont.render("countdown", 1, (0,0,0)) #sekundite lugemine
screen.blit(label, (100, 100)) #Asukoht


#Kiirus ja asukoht
posX,posY=0, screenY/1.5 #aluse asukoht
speedX,speedY=0,0 #aluse kiirus x ja y teljel
posX1,posY1=0,0 #Palli algasukoht
speedX1,speedY1=3,4 #palli kiirused x ja y teljel

#pildid
pall=pygame.Rect(posX1,posY1,20,20) #palli kast kokkupõrgete jaoks
pallp=pygame.image.load("img/ball.png") #Palli pilt
pallp=pygame.transform.scale(pallp, [20,20]) #Palli suurus
pad=pygame.Rect(posX,posY,120,20) #Aluse kast kokkupõrgete jaoks
padp=pygame.image.load("img/pad.png") #Aluse pilt
padp=pygame.transform.scale(padp,[120,20]) #Aluse suurus


#Ajalisamine
start_ticks=pygame.time.get_ticks() #starter tick

#Skoor
score=0

#Loop mängu mängimiseks
while True:
    clock.tick(60) #fps

    #et saaks mängu ristist kinni panna
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()



    #Palli pildi lisamine ekraanile
    pall = pygame.Rect(posX1, posY1, 20, 20) #palli ümber olev ruut kokkupõrgete jaoks
    screen.blit(pallp,pall) #Palli asukoht
    posX1+=speedX1 #Palli asukoht muutub x teljel palli kiirusega
    posY1+=speedY1 #Palli asukkoht muutub Y teljel palli kiirusega

    #kui puudutab ääri, siis muudab suunda
    if posX1 > screenX-pallp.get_rect().width or posX1 < 0:
        speedX1 = -speedX1
    if posY1 < 0:
        speedY1 = -speedY1

    #Kui pall puudutab alumist äärt, siis on mäng läbi.
    if posY1 > screenY - pallp.get_rect().height:
        screen.blit(pygame.font.Font(None,60).render(f"Mäng läbi.", True,[255,0,0]),(120,120))
        pygame.display.flip()
        time.sleep(2)
        quit()


    if event.type == pygame.KEYDOWN: #Kui kasutaja vajutab nupu alla
        if event.key == pygame.K_RIGHT: #Kui kasutaja vajutab paremat noolt, siis liigub alus kiirusega kolm paremale
            speedX = 3
        elif event.key == pygame.K_LEFT: #kui kasutaja vajutab vasakut noolt, siis liigub alus kiirusega kolm vasakule
            speedX = -3




    pad=pygame.Rect(posX,posY,120,20) #Aluse ruut, kokkupõrgete jaoks

    screen.blit(padp,pad) #aluse asukoht

    #Kui alus puudutab paremat või vasakut seina, siis muudab liikumis suunda
    if posX > screenX - padp.get_rect().width or posX < 0:
        speedX = -speedX
    posX += speedX



    #Kui pall läheb vastu alust, siis see muudab suunda Y teljel ja mängija saab 1 punkti juurde
    if pall.colliderect(pad) and speedY1 > 0:
        speedY1=-speedY1
        score+=1

    #Kuvab skoori
    screen.blit(pygame.font.Font(None,30).render(f"Skoor: {int(score)}",True,[255,255,255]),[10,30])


    #kuvame aja
    screen.blit(pygame.font.Font(None,20).render(f"Aeg: {int(time.time()-startTime)}",True,[255,255,255]),[10,460])

    #graafika kuvamine ekraanil
    pygame.display.flip()
    screen.fill(lblue)
